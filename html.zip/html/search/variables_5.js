var searchData=
[
  ['stock',['stock',['../class_stock.html#a55cb69748a14da5fe525e55a2c656ba9',1,'Stock']]],
  ['stock_5fsala',['stock_sala',['../class_sala.html#a7c9511997ba4a6fac93625fd3f5c7703',1,'Sala']]]
];
