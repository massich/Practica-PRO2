var searchData=
[
  ['poner_5fitems',['poner_items',['../class_almacen.html#ad2829b7fb8be4ced00511472636982bf',1,'Almacen::poner_items()'],['../class_sala.html#aa65c68be5f5242570063fc5f0e8dafa2',1,'Sala::poner_items()']]],
  ['poner_5fprod',['poner_prod',['../class_producto.html#aef5383f676b625125d6d4a754e457af3',1,'Producto::poner_prod()'],['../class_stock.html#a06c7f65bcdd419950fa2c00fd638c03b',1,'Stock::poner_prod()']]]
];
