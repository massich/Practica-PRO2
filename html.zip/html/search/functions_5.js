var searchData=
[
  ['imprimir_5fstring',['imprimir_string',['../sala_8cc.html#ac1916f29be6c9137b2df1079e26c54f3',1,'sala.cc']]],
  ['inventario',['inventario',['../class_stock.html#ab92820b495a64f2a7aef5b071644909a',1,'Stock']]]
];
