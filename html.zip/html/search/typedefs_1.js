var searchData=
[
  ['row',['Row',['../sala_8hh.html#aa33775a3e721e5fbd17b48a94ed3ca94',1,'sala.hh']]]
];
