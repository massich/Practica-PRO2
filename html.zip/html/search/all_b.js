var searchData=
[
  ['quitar_5fitems',['quitar_items',['../class_almacen.html#a9352bd3ee6b624a02283c627d27aec3e',1,'Almacen::quitar_items()'],['../class_sala.html#afcdc6c283e5fca9632f279142ad613c3',1,'Sala::quitar_items()']]],
  ['quitar_5fprod',['quitar_prod',['../class_producto.html#a7223d677ba9a0844072904602fb3b0f1',1,'Producto::quitar_prod()'],['../class_stock.html#aaa1564711f0e6aa0a8093f53a3dad0b4',1,'Stock::quitar_prod()']]]
];
