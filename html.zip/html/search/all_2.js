var searchData=
[
  ['capacitat_5factual',['capacitat_actual',['../class_almacen.html#ab340c6592772278729f802dbb13a52d2',1,'Almacen::capacitat_actual()'],['../class_sala.html#ac1bcf6e4f9a336b505a362468411af20',1,'Sala::capacitat_actual()']]],
  ['compactar',['compactar',['../class_almacen.html#a07e1c7a15df51e7361c81104044e83c6',1,'Almacen::compactar()'],['../class_sala.html#aac11486a22560bdcdb7771e9692cfa75',1,'Sala::compactar()']]],
  ['comprobar_5fprod',['comprobar_prod',['../class_stock.html#ae1fe35478f2eeae0f91216e7c25e33e6',1,'Stock']]],
  ['consul_5fidentificador',['consul_identificador',['../class_producto.html#ae0067962ae16d3c12fb6dda463562245',1,'Producto']]],
  ['consul_5funidades',['consul_unidades',['../class_producto.html#aa26e89579230adf0e1e40460a04ff36f',1,'Producto']]],
  ['consultar_5fpos',['consultar_pos',['../class_almacen.html#a18a63aaa7ce218993dcb4619e17b7633',1,'Almacen::consultar_pos()'],['../class_sala.html#a611c18b0ebd5fd9c8ec386809b363d50',1,'Sala::consultar_pos()']]],
  ['consultar_5fprod',['consultar_prod',['../class_stock.html#aadb2f269b75da29388c0e8b7055b44ce',1,'Stock']]]
];
