var searchData=
[
  ['estanteria',['estanteria',['../class_sala.html#a8f5264818c98db9c0d075c51a7672d95',1,'Sala']]]
];
