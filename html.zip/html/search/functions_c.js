var searchData=
[
  ['sala',['Sala',['../class_sala.html#a7b265bb95493f0c161e6403f7295a084',1,'Sala']]],
  ['sumar_5fstock',['sumar_stock',['../class_sala.html#a91e0acab4f56f3a5cbcad80afe163de8',1,'Sala::sumar_stock()'],['../class_stock.html#a13f036a59415e6b865a3011ecd64d060',1,'Stock::sumar_stock()']]]
];
