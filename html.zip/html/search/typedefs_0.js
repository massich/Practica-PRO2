var searchData=
[
  ['matrix',['Matrix',['../almacen_8hh.html#acdf2b2dca71b1d617c96d1afa6a525fa',1,'Matrix():&#160;almacen.hh'],['../sala_8hh.html#a274a66ac4d9c777e113af0a65bb3912a',1,'Matrix():&#160;sala.hh']]]
];
