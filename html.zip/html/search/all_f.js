var searchData=
[
  ['unidades',['unidades',['../class_producto.html#a391646f51e9bbbd3cf22abdbd74eaac6',1,'Producto']]]
];
